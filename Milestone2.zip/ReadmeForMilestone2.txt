Index files are too large to upload.
You can download them at : 
https://onedrive.live.com/redir?resid=99CE2BA467B21DE5!99602&authkey=!AFECj4t1Cwzb-pU&ithint=folder%2cser
Some issues we encountered include:
1. Our searches will favor pages with large number of one term over pages that might be more relevant with all terms in query.
2. First search takes long time becuse we must load the index into memory. 